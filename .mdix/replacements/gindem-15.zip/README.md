# gindema

Closed-source code/binary protection core **and** gameplay video/image poisoning tool, in one workspace, distributed as public CLIs. Blocks AI-assisted decompilation and reverse engineering, and disrupts AI vision models that would otherwise clone a game from posted gameplay footage.

## Status

Protection core: `gindema-ptr` (vendored type-erased pointer primitives),
`gindema-bits` (bit-level stream I/O — see `docs/gindema-bits.md` for why
this ended up written fresh rather than literally vendored), and
`gindema-vm` (the baseline bytecode interpreter, with `OpcodeMap`/
`remap_program` for per-build remapping, `Program::to_bytes`/`from_bytes`
for persisting a program to a file, `assemble` — a minimal textual
assembly language, so a program no longer has to be built by calling
`ProgramBuilder` methods directly in Rust — and now `decode_program`
(structured decoding of an already-built program) and `interleave_fluff`
(state-dependent decoding's bytecode-format mechanism)) are implemented
and tested. `gindema-obfuscate` now has all four of its passes — per-build
opcode remap, honeypot/dead-end injection, control-flow flattening (a
single dispatcher loop every inter-block transfer routes through), and
state-dependent decoding (`obfuscate_with_fluff`) — see
`docs/gindema-obfuscate.md` for honest limits on how strong each one
currently is, and for the one correct pipeline order (honeypot, then
flatten, then fluff, then opcode remap) the four compose in. `gindema-guard`
has its first real pass too — timing/checksum watchdog plus
pollution-state reads, see `docs/gindema-guard.md` for real limits — but
doesn't use `gindema-ptr` yet and isn't wired into anything.
`gindema-common` has two real things in it now (a shared checksum, used by
`gindema-guard`; a shared `SplitMix64`, used by `gindema-obfuscate` and
`gindema-container`), though not yet the shared error types/traits its own
description names. `gindema-cli` is a real, working pipeline —
`demo`/`assemble`/`info`/`run`/`remap`/`flatten`/`fluff`/`pack`/`unpack` —
that now uses every crate in the workspace except `gindema-guard` (which
has no game here to protect); see `docs/gindema-cli.md` for why that one
still isn't wired up, and for the recommended `flatten` → `fluff` →
`remap` pipeline order if you want all three on one program. `gindema-container` is implemented too: an encrypted asset
archive built on `dixscript`'s real AES-256-GCM/gzip primitives (not its
AST-driven pipeline — see `docs/gindema-container.md` for why), with
honeypot slots and lazy per-asset decryption. Building and testing it
means `dixscript`'s own crypto code actually ran in the sandbox, a
deliberate departure from this project's earlier "don't execute
DixScript-Rust" practice — flagged prominently in that doc rather than
done quietly. **The whole workspace's `ci.yml` has been run for real on
GitHub Actions once already** (rustc 1.100.0, commit `f8e0115`: 189 tests
passed, clippy and fmt both clean) — every crate up to that point,
`gindema-container` included, had only ever been sandbox-verified before
that. `gindema-vm`'s `decode_program`/`interleave_fluff`,
`gindema-obfuscate`'s `flatten_control_flow`/`obfuscate_with_fluff`
(control-flow flattening and state-dependent decoding), and `gindema-cli`'s
new `flatten`/`fluff` subcommands exposing them were all added after that
confirmed run and are **sandbox-verified only so far** — not yet through a
real CI run of their own.
`mirage-ffmpeg` and `mirage-cli` are also still scaffold stage. `pixelflip-*`
is real and working. `mirage-core` (pattern format and frame application)
and `mirage-train` (offline training and evaluation against CLIP) are
implemented and tested, but a trained pattern's effectiveness against the
real CLIP checkpoint has only been partly measured; see
`docs/mirage-train.md`.

## Toolchain: stable (1.100 at time of writing), not 1.75, 1.85 or 1.88

Originally pinned to `rust-version = "1.75"` (inherited from mid-engine's
convention). That floor has been raised three times, each time because a real
CI run said so:

- **1.85** (first guess, for the `edition2024` dependencies): `mirage-train
  bench` #1 failed at dependency resolution. `image 0.25.10` and `zip 9.6.0`
  (pulled in by `candle-core`) both require 1.88.
- **1.88**: `mirage-train bench` #2 resolved fine, then failed compiling
  `candle-core 0.11.1` itself. Its x86 quantized kernels
  (`quantized/repack_x86.rs`, not behind any cargo feature) use AVX-512 and
  `avxvnni` target features and intrinsics, which were unstable before Rust
  1.89, and call `__cpuid_count` from safe code, which only became a safe
  function in `stdarch` after the revision that shipped in Rust 1.92.
  `candle-core` declares no `rust-version`, so Cargo can't warn about any of
  this up front.
- **Now**: CI builds on `stable` and `[workspace.package] rust-version` is
  1.100, the version that was current when this was last verified. The real
  floor is somewhere above 1.92 and hasn't been bisected, since these ship as
  prebuilt binaries and nobody downstream builds them from source.

The earlier "verified clean at 1.85+" claim in this file was wrong and has
been removed. `resolver = "3"` is set, so Cargo prefers dependency versions
compatible with the declared `rust-version` instead of always taking the
newest.

## Workspace layout

Protection core:
- `crates/gindema-common` - shared types/errors (used workspace-wide)
- `crates/gindema-vm` - the custom bytecode VM
- `crates/gindema-obfuscate` - compiler passes
- `crates/gindema-guard` - runtime anti-tamper watchdog
- `crates/gindema-container` - encrypted asset container (built on dixscript)
- `crates/gindema-ptr` - vendored type-erased pointer primitives (from mid-engine's `mid-ptr`)
- `crates/gindema-bits` - bit-level stream I/O for the VM's bytecode format (not vendored after all — see `docs/gindema-bits.md`)
- `crates/gindema-cli` - the distributable protection-core CLI

Video/image poisoning (placeholder name "mirage", rename before shipping):
- `crates/mirage-core` - pattern format and frame application (runtime side)
- `crates/mirage-ffmpeg` - FFmpeg integration
- `crates/mirage-train` - offline PGD training and evaluation of the perturbation pattern against CLIP
- `crates/mirage-cli` - the distributable video-poisoning CLI

Visual effects (unrelated to the anti-AI purpose, just a styling tool):
- `crates/pixelflip-core` - pattern-based pixel negation effects
- `crates/pixelflip-cli` - the distributable effects CLI

## License

Proprietary, MidManStudio. See `LICENSE`.
