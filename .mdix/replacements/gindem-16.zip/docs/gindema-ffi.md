# gindema-ffi

## Overview

The first FFI surface this workspace has had: a C ABI over `gindema-guard`
(runtime anti-tamper) and `gindema-container` (encrypted asset reading),
for a native game written in C, C#, or anything else that can link a C
library. Everything else in this workspace (`gindema-vm`, `gindema-obfuscate`,
`gindema-cli`, `gindema-container`'s own build side) stays Rust-only, by
design — this crate exists specifically because a shipped game's own native
process is the one place something has to be callable from outside Rust.

**Why Tower of Babylon specifically shaped this.** The project owner
pointed at `MidManStudio/tower-of-babylon` (a C99 + raylib multiplayer game,
browser/WebAssembly and Android) as a real integration target, so this
crate's conventions were read off that repo's own existing Rust FFI
integration rather than invented fresh:

- `docs/android.md` and `docs/net.md` there already link one Rust static
  library — mid-engine's `mid_net_quic` (`mid-net-transport-quinn-ffi`) —
  built with `cargo rustc --crate-type staticlib`, declared via a
  hand-written header (`src/net/mid_net_quic.h`, a kept-in-sync copy of the
  crate's own `smoke-test/mid_net_quic.h`), and verified before that project
  ever linked it by a real C program (`smoke-test/test.c`) built against
  both the static and shared forms.
- **Status codes, panic-guarding, null-checks-first, opaque handles made
  with a `_new`/`_open` and freed with a matching `_free`** are all
  `mid-net-transport-quinn-ffi`'s own conventions, copied here deliberately
  — see `lib.rs`'s own doc comment for the exact list. A header someone
  from that project opens should already feel familiar.
- **One consolidated library, not one per crate.** A native program can
  link exactly one Rust `staticlib`'s worth of `std`/`core`/
  `compiler_builtins` symbols — mid-engine's own docs state this plainly
  (`mid-net-transport-quinn-ffi` absorbs its facade crate's driver/server
  FFI into one library for exactly this reason: "two Rust static libraries
  cannot be linked into one program"). So `gindema-ffi` is one crate
  covering `gindema-guard` and `gindema-container` now, with room (see
  "Known limits") for `gindema-vm` later, rather than a separate FFI crate
  per protection-core crate.
- **The web/WASM build is explicitly out of scope for this pass.**
  Tower of Babylon's own `docs/platforms.md` is direct about this:
  `TOWER_MIDNET` is a hard `#error` on the web build (`mid_net_quic` needs
  real sockets a browser sandbox doesn't expose the same way), so that
  project's own precedent for a *native* Rust library is Android/Desktop
  only. A **separate** precedent exists there for bringing Rust-ish code
  into the *browser* build specifically — `TOWER_MDIX_WASM_BRIDGE`, an
  `EM_JS` bridge to DixScript's own published WebAssembly build (DixScript
  already ships WASM bindings; this is not this crate's own doing) — but
  that is a materially different integration path (no `staticlib`, no C
  ABI, a JS bridge instead), scoped to reading `.mdix` config at runtime,
  not to anything `gindema-guard`/`gindema-container` need. Building an
  analogous web path for this crate is real, separate future work, not
  attempted here.

This crate only ever **reads** what it's handed: `gindema-container`'s
`ContainerBuilder` (building an archive) has no FFI surface at all, since
that's a build-time job `gindema-cli pack` already covers — a shipped game
has no reason to construct a container archive of its own at runtime.
Likewise, `gindema-obfuscate`'s four passes all run at build time (already
reachable through `gindema-cli`'s `flatten`/`fluff`/`remap`); nothing here
wraps them, by design, not by omission.

## Modules

### `lib.rs`
**What it does:** crate doc (the "Why one library" / conventions summary
condensed from this doc's Overview above), module wiring, flat re-exports
of every `gindema_*` function and type.

### `status.rs`
**What it does:** `GindemaStatus` (`#[repr(i32)]`: `Ok` 0, `NullPointer`
-1, `BufferTooSmall` -2, `InternalPanic` -6 — the same numbers
`mid-net-transport-quinn-ffi`'s own `MidNetQuicStatus`/`mid_net.h` use for
the same cases, so a program linking both sees one convention, not two;
`gindema`-specific codes for the read-only `ContainerError` cases start at
-20, leaving a gap rather than implying a relationship that isn't there),
`From<ContainerError> for GindemaStatus` (the build-only variants —
`EmptyAsset`/`Compress`/`Encrypt` — have no case, since this crate's
read-only surface can never produce them; mapping them would be untestable
dead code), and `guard(impl FnOnce() -> i32) -> i32`, the
`catch_unwind`-based panic-to-status-code wrapper every status-returning
`gindema_*` function goes through (one returning some other type —
a count, a pointer, a bare bool — uses `catch_unwind` directly with its own
fallback instead, since `guard`'s signature is specifically `-> i32`).

**Tests:** inline. The four shared codes have their documented numeric
values; `guard` turns a panic into `InternalPanic` rather than letting it
unwind, and passes an ordinary return straight through; every
`ContainerError` variant this crate can actually produce maps to a
distinct `GindemaStatus`.

### `guard_ffi.rs`
**What it does:** opaque handles and C functions for `GuardState`,
`TimingWindow`, `Watch`, and two concrete instantiations of the generic
`Guarded<T>` (`Guarded<i64>`, `Guarded<f64>` — C has no generics, and an
integer stat or a float one covers what a game's values realistically ever
need), plus standalone `gindema_checksum`/`gindema_checksums_match`
wrapping `gindema_common`'s functions directly (what `Watch` uses
internally, exposed for a caller that wants to manage its own "expected
value" — in a save file, say — without keeping a `GindemaWatch` handle
alive). Every stateful type: a `_new`/`_start` constructor that can't fail
(returns a real pointer, never null), paired accessor/mutator functions,
and a `_free` that accepts null safely. Written out twice rather than
macro-generated for the two `Guarded` instantiations — each is short, and
grepping for `guarded_i64` shouldn't require also understanding a macro.

**A genuinely empty region (`data` null, `len` zero) is accepted, not
rejected**, for every function taking a `(data, len)` pair — only `data`
null *with* `len` nonzero is treated as the real null-pointer error. This
matters for `gindema_watch_new`/`gindema_watch_check` specifically: a game
might legitimately want to watch a zero-length region (a flag that starts
unallocated, say) without that being indistinguishable from a caller
mistake.

**Tests:** inline, 11. Guard state round-trips clean → polluted, and
rejects/no-ops on null correctly; a timing window's elapsed time is
non-negative and grows, and its threshold check both fires and doesn't;
a watch catches tampering and leaves clean data alone, polluting the
right state either way, and both accepts a genuinely empty region and
rejects null-with-nonzero-len; both guarded types fall back to their decoy
exactly once their shared state is polluted; checksums computed from the
same bytes match, different bytes don't.

### `container_ffi.rs`
**What it does:** `gindema_container_key_from_base64` (parses the base64
form `gindema-cli pack` prints into 32 raw bytes) and
`GindemaContainerReader` (`gindema_container_open`/`_asset_count`/
`_read_asset_len`/`_read_asset`/`_free`) — read-only access to an archive
already built elsewhere.

**The opaque reader owns a copy of the data, not a borrow — deliberately,
to sidestep a self-referential struct.** `gindema_container::ContainerReader<'a>`
borrows the archive bytes it was opened with; storing both the owned bytes
and a `ContainerReader` borrowing from them in the same Rust struct is a
self-referential layout safe Rust has no way to express directly (it would
need `unsafe` pointer tricks, or a crate like `ouroboros`, either adding
real risk or a new dependency for what turns out to be an avoidable
problem). Instead, `GindemaContainerReader` holds just `{ data: Vec<u8>,
key: ContainerKey }`, and every accessor calls `ContainerReader::open`
fresh via a small `reopen()` helper. This only re-decrypts the small
index, not any asset (`ContainerReader::open`'s own docs), so the repeated
work is cheap — not a measurable cost for how a game actually loads assets
(occasionally, not per frame), and `gindema_container_open` itself still
opens once up front too, specifically so a bad key or a corrupted archive
is caught immediately rather than on the first real read.

**The two-call `_read_asset_len` then `_read_asset` shape** lets a caller
allocate a buffer of exactly the right size once, rather than guessing and
retrying — more useful for a one-shot asset load than a polling-style
"try with this buffer, told how big the real thing is on failure" shape
would be. `_read_asset` still refuses a too-small buffer cleanly
(`GindemaStatus::BufferTooSmall`, nothing written) for a caller that skips
the length call anyway.

**`gindema-container` gained one small, backward-compatible addition for
this crate's sake:** `ContainerKey::from_bytes([u8; 32]) -> Self` — there
was previously no way to build a key from raw bytes at all (only
`generate()` or `from_base64()`), which this crate's C ABI needs since a
key arrives as a 32-byte buffer, not a string. The `[u8; 32]` parameter
(not a `&[u8]` needing a length check) makes a wrong-length error
impossible by construction. See `docs/gindema-container.md` for where this
sits in that crate's own docs.

**Tests:** inline, 7, including a round trip through `ContainerBuilder`
(building a tiny real archive, then opening and reading it back entirely
through the C-facing functions). A base64 key round-trips through the ABI
and garbage text is refused; opening, reading every asset, and getting
exact bytes back all work; a too-small read buffer is refused without
writing anything; the wrong key is rejected (`DecryptFailed`, matching
`gindema-cli unpack`'s own behavior for the same case); an out-of-range
asset id is reported, not panicked; null pointers are rejected everywhere,
never dereferenced.

### `smoke-test/` — real, compiled C verification
**What it is:** `gindema.h` (hand-written, matching the Rust source line
for line, the same reasoning `mid-net-transport-quinn-ffi`'s own header
gives — see Overview) and `test.c` (36 checks, the same `CHECK` macro
style as mid-engine's `smoke-test/test.c`), plus `fixture.gctn`, a real
archive built with `gindema-cli pack fixture.gctn asset0.bin asset1.bin
--honeypots 2 --seed 7` — not a synthetic test fixture, but this crate's
companion CLI's real output, so the smoke test also proves the CLI's
`pack` and this crate's reading are actually interoperable, not each only
tested in isolation against their own crate's internals.

**Verified against both library forms, exactly like mid-engine's own
convention** (build lines are comments at the bottom of `test.c`, same
placement):
```
gcc -Wall -Wextra -o test_static test.c -I. ../../../target/debug/libgindema.a -lpthread -ldl -lm
./test_static
gcc -Wall -Wextra -o test_shared test.c -I. -L../../../target/debug -lgindema
LD_LIBRARY_PATH=../../../target/debug ./test_shared
```
Both: **36/36 checks passed**, exit code 0, zero compiler warnings. (The
static form needs the archive passed as a direct path, not `-lgindema` —
`gcc` silently prefers the `.so` over the `.a` when both sit in the same
`-L` directory and nothing forces otherwise; passing `libgindema.a`'s path
directly sidesteps that rather than fighting linker flags to force it.)
Covers: guard-state pollution and its null handling; a timing window's
elapsed time and threshold check; a watch catching real tampering and
leaving clean data alone; both guarded types falling back to their decoy;
checksums; and the full container path — open with the right key, read
both real assets byte-for-byte, a too-small buffer, an invalid asset id,
and the wrong key rejected (visibly, via dixscript's own logged decryption
error on stderr — expected output for that one check, not a test failure).

## Known limits (intentional, for this pass)

- **`gindema-vm` has no FFI surface yet.** Running a specific obfuscated
  routine from C needs a decision this crate shouldn't make unilaterally —
  which routine, what inputs/outputs it needs — so it's left for whoever's
  actually integrating a specific protected calculation to specify. The
  "one library" design above leaves room for it: it would become a third
  module in this same crate, not a new one.
- **The web/WASM build is out of scope for this pass** — see Overview's
  "Why Tower of Babylon specifically shaped this" for the real precedent
  gap this leaves (an `EM_JS`/WASM-bridge path exists in that project for
  DixScript already, but nothing analogous exists for this crate, and
  building one is separate, real work).
- **Two native-static-library projects wanting both `mid_net_quic` and
  `gindema` still hit the exact problem "one library" was designed to
  avoid *within* this crate's own surface, just one level up** — a program
  cannot link two independently-built Rust `staticlib`s together even if
  neither one individually duplicates anything the other needs. This
  crate's own fix is building as a `cdylib` too (`crate-type = ["lib",
  "cdylib", "staticlib"]`): if a native build already spends its "one
  static Rust library" slot on `mid_net_quic`, it can link `libgindema.so`
  dynamically instead, at the cost of shipping (and loading) an extra
  shared object. Not resolved more deeply than offering that choice —
  doing so would mean touching Tower of Babylon's own build scripts
  (`scripts/build_android.sh` and friends), which this delivery doesn't
  do, since nobody's asked this crate to actually be wired into that
  repo's build yet, only to exist and be real.
- **No Android/Desktop build-script integration exists for this crate
  itself** (unlike `mid_net_quic`, which Tower of Babylon's
  `scripts/build_android.sh` already builds and links as a documented
  stage) — this pass produces a working, C-tested library and header;
  wiring a `cargo rustc --target armv7-linux-androideabi --crate-type
  staticlib -p gindema-ffi` stage into an actual game's build is the next
  real step, not attempted here.
- **`gindema_container_open` re-validates by calling `ContainerReader::open`
  an extra time up front**, on top of the one every subsequent accessor
  call makes internally (see `container_ffi.rs`'s own notes above) — one
  redundant index-decrypt per archive open, traded deliberately for
  surfacing a bad key/corrupted archive immediately rather than on the
  first real read.
- **`libgindema.a` is large** (around 70 MB, release build) — normal for
  a Rust `staticlib` (it carries the whole of `std`/`core`/
  `compiler_builtins` statically; a final linker strips what the rest of
  the program doesn't reference), not a sign of bloat specific to this
  crate's own small surface, but worth knowing going in rather than being
  surprised by it.

## CI and Workflows

See `.github/workflows/ci.yml` (workspace-wide, workflow_dispatch only).
`cargo test -p gindema-ffi` runs 21 unit tests (11 in `guard_ffi.rs`, 7 in
`container_ffi.rs`, 3 in `status.rs`); `cargo clippy -p gindema-ffi
--all-targets -- -D warnings` and `cargo fmt -p gindema-ffi -- --check` are
both clean. `gindema-container` gained one more test for its new
`from_bytes` constructor (19 total, up from 18). Beyond the Rust tests,
`smoke-test/test.c` was compiled and run for real against both the static
and shared library forms — 36/36 checks passed in each, zero compiler
warnings — not just `cargo test`. Verified in the sandbox on Rust 1.100;
not yet confirmed on the real GitHub Actions runner (added after the
commit `f8e0115` confirmation; see the root `README.md`/`CHANGELOG.md`).

## Fixes and Problems

- **`unsafe_code` is denied workspace-wide, and an FFI boundary cannot
  exist without it.** Confirmed by actually testing it in the sandbox
  (not assumed): `[lints] workspace = true` takes the workspace's lint
  table as-is, with no way to override one entry from it while still
  inheriting the rest in the same package — a package that wants
  `unsafe_code = "allow"` has to restate every other workspace lint it
  still wants enforced by hand instead. `gindema-ffi`'s `Cargo.toml` does
  exactly that: `[lints.rust] unsafe_code = "allow"`, `missing_docs =
  "warn"` restated, `[lints.clippy] undocumented_unsafe_blocks = "warn"`
  restated — confirmed (by a throwaway test workspace, not guessed) that
  this neither loses `missing_docs`/`undocumented_unsafe_blocks`
  enforcement nor trips the `cargo::missing_lints_inheritance` warning the
  four still-unopted crates (`pixelflip-core`/`pixelflip-cli`/
  `mirage-ffmpeg`/`mirage-cli`) get, since that warning only fires for a
  package with no `[lints]` table at all, not one that declines
  `workspace = true` on purpose.
- **`undocumented_unsafe_blocks` applies inside `#[cfg(test)]` too, and an
  `unsafe` *function*'s body does not implicitly need its own inner
  `unsafe {}` block in edition 2021** (that's an edition-2024 change, via
  `unsafe_op_in_unsafe_fn`) — confirmed directly rather than assumed,
  since getting this wrong either under- or over-constrains where a
  safety comment is actually required. Every raw-pointer operation in this
  crate's real functions is still wrapped in an explicit `unsafe { }` with
  its own `// SAFETY:` comment regardless (matching
  `mid-net-transport-quinn-ffi`'s own style, which does the same inside
  its own `unsafe extern "C" fn` bodies) specifically so the lint catches
  a missing safety comment exactly at the dangerous operation, not just
  "somewhere in an unsafe function" — relying on the whole-function
  grant would hide the real risk sites from the lint entirely. Every one
  of this crate's ~35 test-side calls into its own `unsafe extern "C" fn`s
  needed the identical treatment, which first revealed a real formatting
  trap: `rustfmt` reflowing a multi-line `assert_eq!(unsafe { ... }, ...)`
  can separate a `// SAFETY:` comment from the `unsafe` token it was
  documenting (the comment has to sit immediately above the line the
  `unsafe` keyword itself appears on, not merely above the statement
  containing it) — caught by clippy immediately after a `cargo fmt` pass,
  not missed.
