// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/gindema-ffi.md, section "container_ffi.rs"
// ============================================================================

//! C ABI over `gindema-container` — **read-only**: opening an archive and
//! reading assets out of it, the only two things a shipped game actually
//! does with one at runtime. Building an archive (`ContainerBuilder`) is a
//! build-time job already covered by `gindema-cli pack`; this crate
//! doesn't expose it, since a shipped game has no reason to construct a
//! container archive of its own at runtime.

use std::ffi::CStr;
use std::os::raw::c_char;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::slice;

use gindema_container::{ContainerKey, ContainerReader};

use crate::status::{guard, GindemaStatus};

/// The length, in bytes, of a raw `ContainerKey`. Every function here that
/// takes a key expects a pointer to exactly this many readable bytes.
pub const GINDEMA_CONTAINER_KEY_LEN: usize = 32;

/// Parses a base64-encoded key (the form `gindema-cli pack` prints) and
/// writes the 32 raw key bytes to `out_key`. Status
/// [`GindemaStatus::InvalidKey`] if `base64` isn't valid base64, or
/// doesn't decode to exactly 32 bytes; nothing is written to `out_key` in
/// that case.
///
/// # Safety
/// `base64` must be a valid NUL-terminated C string. `out_key` must be
/// valid for writes of [`GINDEMA_CONTAINER_KEY_LEN`] bytes.
#[no_mangle]
pub unsafe extern "C" fn gindema_container_key_from_base64(
    base64: *const c_char,
    out_key: *mut u8,
) -> i32 {
    guard(|| {
        if base64.is_null() || out_key.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        // function's own contract.
        // SAFETY: non-null, and a valid NUL-terminated string per the
        let s = match unsafe { CStr::from_ptr(base64) }.to_str() {
            Ok(s) => s,
            Err(_) => return GindemaStatus::InvalidKey.code(),
        };
        let key = match ContainerKey::from_base64(s) {
            Ok(k) => k,
            Err(e) => return GindemaStatus::from(e).code(),
        };
        let bytes = key_to_bytes(&key);
        // function's own contract.
        // SAFETY: valid for a GINDEMA_CONTAINER_KEY_LEN-byte write per the
        unsafe { std::ptr::copy_nonoverlapping(bytes.as_ptr(), out_key, bytes.len()) };
        GindemaStatus::Ok.code()
    })
}

/// Opaque handle: see `gindema_container_open`.
///
/// Holds an owned copy of the archive bytes and the key, not a borrow of
/// anything the caller passed in — `open`/`read_asset` are cheap enough
/// (only the small index is ever decrypted up front; see
/// `gindema_container::ContainerReader::open`'s own docs) that this calls
/// `ContainerReader::open` fresh each time rather than keeping one alive
/// across a self-referential struct, which Rust's borrow checker has no
/// safe way to express directly. See `docs/gindema-ffi.md`'s
/// `container_ffi.rs` section for the full reasoning.
pub struct GindemaContainerReader {
    data: Vec<u8>,
    key: ContainerKey,
}

impl GindemaContainerReader {
    fn reopen(&self) -> Result<ContainerReader<'_>, gindema_container::ContainerError> {
        ContainerReader::open(&self.data, self.key.clone())
    }
}

/// Copies `data`/`key`, opens the archive once to validate it (the actual
/// error this can catch, surfaced here rather than discovered on the first
/// `gindema_container_read_asset_len` call), and writes a handle to
/// `*out` on success.
///
/// # Safety
/// `data` must be valid for reads of `data_len` bytes. `key` must be valid
/// for reads of [`GINDEMA_CONTAINER_KEY_LEN`] bytes. `out` must be valid
/// for one write of a pointer.
#[no_mangle]
pub unsafe extern "C" fn gindema_container_open(
    data: *const u8,
    data_len: usize,
    key: *const u8,
    out: *mut *mut GindemaContainerReader,
) -> i32 {
    guard(|| {
        if data.is_null() || key.is_null() || out.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        // SAFETY: non-null, and valid per the function's own contract.
        let data_bytes = unsafe { slice::from_raw_parts(data, data_len) }.to_vec();
        // per the function's own contract.
        let key_bytes: [u8; GINDEMA_CONTAINER_KEY_LEN] =
            // SAFETY: non-null, and valid for GINDEMA_CONTAINER_KEY_LEN bytes
            unsafe { slice::from_raw_parts(key, GINDEMA_CONTAINER_KEY_LEN) }
                .try_into()
                .expect("slice::from_raw_parts was given exactly GINDEMA_CONTAINER_KEY_LEN bytes");
        let container_key = ContainerKey::from_bytes(key_bytes);

        // Validate once up front: open-and-discard. Cheap (index only).
        if let Err(e) = ContainerReader::open(&data_bytes, container_key.clone()) {
            return GindemaStatus::from(e).code();
        }

        let handle = Box::new(GindemaContainerReader {
            data: data_bytes,
            key: container_key,
        });
        // contract.
        // SAFETY: valid for one pointer write per the function's own
        unsafe { *out = Box::into_raw(handle) };
        GindemaStatus::Ok.code()
    })
}

/// How many real assets the archive holds (honeypot slots don't count).
/// `0` if `reader` is null.
///
/// # Safety
/// `reader`, if non-null, must be a live value `gindema_container_open`
/// returned.
#[no_mangle]
pub unsafe extern "C" fn gindema_container_asset_count(
    reader: *const GindemaContainerReader,
) -> u32 {
    catch_unwind(AssertUnwindSafe(|| {
        if reader.is_null() {
            return 0;
        }
        // SAFETY: non-null, and live per the function's own contract.
        let reader = unsafe { &*reader };
        match reader.reopen() {
            Ok(r) => u32::try_from(r.asset_count()).unwrap_or(u32::MAX),
            Err(_) => 0,
        }
    }))
    .unwrap_or(0)
}

/// The byte length of asset `asset_order` (so a caller can allocate a
/// buffer of exactly that size before calling
/// `gindema_container_read_asset`) — always non-negative on success, or a
/// negative `GindemaStatus` (`InvalidAssetId` if no slot holds that order).
///
/// # Safety
/// `reader` must be a live value `gindema_container_open` returned.
#[no_mangle]
pub unsafe extern "C" fn gindema_container_read_asset_len(
    reader: *const GindemaContainerReader,
    asset_order: u32,
) -> i64 {
    catch_unwind(AssertUnwindSafe(|| {
        if reader.is_null() {
            return i64::from(GindemaStatus::NullPointer.code());
        }
        // SAFETY: non-null, and live per the function's own contract.
        let reader = unsafe { &*reader };
        let opened = match reader.reopen() {
            Ok(r) => r,
            Err(e) => return i64::from(GindemaStatus::from(e).code()),
        };
        match opened.read_asset(asset_order) {
            Ok(bytes) => i64::try_from(bytes.len()).unwrap_or(i64::MAX),
            Err(e) => i64::from(GindemaStatus::from(e).code()),
        }
    }))
    .unwrap_or(i64::from(GindemaStatus::InternalPanic.code()))
}

/// Decrypts and decompresses asset `asset_order`, writing it to `buf`.
/// Returns the number of bytes written (always non-negative) on success,
/// [`GindemaStatus::BufferTooSmall`] if `cap` is smaller than the asset's
/// real length (nothing is written in that case — call
/// `gindema_container_read_asset_len` first to size `buf` exactly), or
/// another negative `GindemaStatus` for a bad `asset_order` or a corrupted
/// archive.
///
/// # Safety
/// `reader` must be a live value `gindema_container_open` returned. `buf`
/// must be valid for writes of `cap` bytes.
#[no_mangle]
pub unsafe extern "C" fn gindema_container_read_asset(
    reader: *const GindemaContainerReader,
    asset_order: u32,
    buf: *mut u8,
    cap: usize,
) -> i64 {
    catch_unwind(AssertUnwindSafe(|| {
        if reader.is_null() || buf.is_null() {
            return i64::from(GindemaStatus::NullPointer.code());
        }
        // SAFETY: non-null, and live per the function's own contract.
        let reader = unsafe { &*reader };
        let opened = match reader.reopen() {
            Ok(r) => r,
            Err(e) => return i64::from(GindemaStatus::from(e).code()),
        };
        let bytes = match opened.read_asset(asset_order) {
            Ok(b) => b,
            Err(e) => return i64::from(GindemaStatus::from(e).code()),
        };
        if bytes.len() > cap {
            return i64::from(GindemaStatus::BufferTooSmall.code());
        }
        // own contract (`bytes.len() <= cap`, just checked).
        // SAFETY: valid for a `bytes.len()`-byte write per the function's
        unsafe { std::ptr::copy_nonoverlapping(bytes.as_ptr(), buf, bytes.len()) };
        i64::try_from(bytes.len()).unwrap_or(i64::MAX)
    }))
    .unwrap_or(i64::from(GindemaStatus::InternalPanic.code()))
}

/// Frees a container reader. Safe to call with null.
///
/// # Safety
/// `reader`, if non-null, must be a live value `gindema_container_open`
/// returned, and must not be used (including freed again) afterward.
#[no_mangle]
pub unsafe extern "C" fn gindema_container_free(reader: *mut GindemaContainerReader) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if reader.is_null() {
            return;
        }
        // used again after this (the caller's contract).
        // SAFETY: non-null, and live per the function's own contract; not
        let _ = unsafe { Box::from_raw(reader) };
    }));
}

/// There is no public accessor for `ContainerKey`'s raw bytes (by design —
/// see `gindema-container`, which never needs one), so this crate gets
/// them the one way available from outside that crate: through
/// `to_base64`, decoded back to raw bytes. Only ever called with a key
/// this crate itself just built from exactly 32 bytes, so the length can
/// never actually mismatch.
fn key_to_bytes(key: &ContainerKey) -> [u8; GINDEMA_CONTAINER_KEY_LEN] {
    use base64::engine::general_purpose::STANDARD;
    use base64::Engine as _;
    STANDARD
        .decode(key.to_base64())
        .expect("ContainerKey::to_base64 always encodes a valid key")
        .try_into()
        .expect("a ContainerKey is always exactly 32 bytes")
}

#[cfg(test)]
mod tests {
    use super::*;
    use gindema_container::ContainerBuilder;

    // Same note as guard_ffi.rs's test module: every unsafe block below
    // calls this crate's own already-documented functions with handles
    // this same test just created, so each call satisfies that function's
    // contract -- restated tersely at each site to satisfy
    // undocumented_unsafe_blocks, which is enforced in tests too.

    fn sample_archive() -> (Vec<u8>, ContainerKey, Vec<u8>, Vec<u8>) {
        let mut builder = ContainerBuilder::new();
        let texture = b"pretend texture bytes".to_vec();
        let sound = b"pretend sound bytes, a bit longer than the texture".to_vec();
        builder.add_asset(texture.clone()).unwrap();
        builder.add_asset(sound.clone()).unwrap();
        let key = ContainerKey::generate();
        let archive = builder.build(&key, 3, 42).unwrap();
        (archive, key, texture, sound)
    }

    #[test]
    fn key_from_base64_round_trips_through_the_c_abi() {
        let key = ContainerKey::generate();
        let b64 = std::ffi::CString::new(key.to_base64()).unwrap();
        let mut out = [0u8; GINDEMA_CONTAINER_KEY_LEN];
        // GINDEMA_CONTAINER_KEY_LEN-byte write target.
        let status =
            // SAFETY: b64 is a valid NUL-terminated C string; out is a valid
            unsafe { gindema_container_key_from_base64(b64.as_ptr(), out.as_mut_ptr()) };
        assert_eq!(status, GindemaStatus::Ok.code());
        assert_eq!(ContainerKey::from_bytes(out), key);
    }

    #[test]
    fn key_from_base64_rejects_garbage() {
        let bad = std::ffi::CString::new("not valid base64 at all!!").unwrap();
        let mut out = [0u8; GINDEMA_CONTAINER_KEY_LEN];
        let status =
            // SAFETY: bad is a valid NUL-terminated C string; out is a valid write target.
            unsafe { gindema_container_key_from_base64(bad.as_ptr(), out.as_mut_ptr()) };
        assert_eq!(status, GindemaStatus::InvalidKey.code());
    }

    #[test]
    fn open_then_read_every_asset_round_trips_exactly() {
        let (archive, key, texture, sound) = sample_archive();
        let key_bytes = key_to_bytes(&key);

        let mut reader_ptr: *mut GindemaContainerReader = std::ptr::null_mut();
        // valid pointer-write target.
        // SAFETY: archive/key_bytes are valid for their own lengths; out is a
        let status = unsafe {
            gindema_container_open(
                archive.as_ptr(),
                archive.len(),
                key_bytes.as_ptr(),
                &mut reader_ptr,
            )
        };
        assert_eq!(status, GindemaStatus::Ok.code());
        assert!(!reader_ptr.is_null());

        // SAFETY: reader_ptr is a live value gindema_container_open just returned.
        assert_eq!(unsafe { gindema_container_asset_count(reader_ptr) }, 2);

        for (order, expected) in [(0u32, &texture), (1u32, &sound)] {
            // SAFETY: reader_ptr is live.
            let len = unsafe { gindema_container_read_asset_len(reader_ptr, order) };
            assert_eq!(len, expected.len() as i64);
            let mut buf = vec![0u8; len as usize];
            // SAFETY: reader_ptr is live; buf is valid for buf.len() writes.
            let written = unsafe {
                gindema_container_read_asset(reader_ptr, order, buf.as_mut_ptr(), buf.len())
            };
            assert_eq!(written, expected.len() as i64);
            assert_eq!(&buf, expected);
        }

        // SAFETY: reader_ptr is live and not used again after this call.
        unsafe { gindema_container_free(reader_ptr) };
    }

    #[test]
    fn read_asset_into_a_too_small_buffer_is_refused_cleanly() {
        let (archive, key, texture, _sound) = sample_archive();
        let key_bytes = key_to_bytes(&key);
        let mut reader_ptr: *mut GindemaContainerReader = std::ptr::null_mut();
        // pointer-write target.
        // SAFETY: archive/key_bytes valid for their own lengths; out is a valid
        unsafe {
            gindema_container_open(
                archive.as_ptr(),
                archive.len(),
                key_bytes.as_ptr(),
                &mut reader_ptr,
            )
        };

        let mut tiny = [0u8; 1];
        assert!(texture.len() > tiny.len());
        // SAFETY: reader_ptr is live; tiny is valid for its own length.
        let result =
            unsafe { gindema_container_read_asset(reader_ptr, 0, tiny.as_mut_ptr(), tiny.len()) };
        assert_eq!(result, i64::from(GindemaStatus::BufferTooSmall.code()));

        // SAFETY: reader_ptr is live and not used again after this call.
        unsafe { gindema_container_free(reader_ptr) };
    }

    #[test]
    fn open_with_the_wrong_key_is_rejected() {
        let (archive, _key, _texture, _sound) = sample_archive();
        let wrong_key = key_to_bytes(&ContainerKey::generate());
        let mut reader_ptr: *mut GindemaContainerReader = std::ptr::null_mut();
        // pointer-write target.
        // SAFETY: archive/wrong_key valid for their own lengths; out is a valid
        let status = unsafe {
            gindema_container_open(
                archive.as_ptr(),
                archive.len(),
                wrong_key.as_ptr(),
                &mut reader_ptr,
            )
        };
        assert_eq!(status, GindemaStatus::DecryptFailed.code());
        assert!(reader_ptr.is_null());
    }

    #[test]
    fn invalid_asset_id_is_reported_not_panicked() {
        let (archive, key, _texture, _sound) = sample_archive();
        let key_bytes = key_to_bytes(&key);
        let mut reader_ptr: *mut GindemaContainerReader = std::ptr::null_mut();
        // pointer-write target.
        // SAFETY: archive/key_bytes valid for their own lengths; out is a valid
        unsafe {
            gindema_container_open(
                archive.as_ptr(),
                archive.len(),
                key_bytes.as_ptr(),
                &mut reader_ptr,
            )
        };

        // SAFETY: reader_ptr is live.
        let len = unsafe { gindema_container_read_asset_len(reader_ptr, 999) };
        assert_eq!(len, i64::from(GindemaStatus::InvalidAssetId.code()));

        // SAFETY: reader_ptr is live and not used again after this call.
        unsafe { gindema_container_free(reader_ptr) };
    }

    #[test]
    fn null_pointers_are_rejected_not_dereferenced() {
        let mut out: *mut GindemaContainerReader = std::ptr::null_mut();
        // dereferenced; out is a valid pointer-write target.
        assert_eq!(
            // SAFETY: null data/key are explicitly documented as rejected, not
            unsafe { gindema_container_open(std::ptr::null(), 0, std::ptr::null(), &mut out) },
            GindemaStatus::NullPointer.code()
        );
        assert_eq!(
            // SAFETY: null is an explicitly documented, accepted input here.
            unsafe { gindema_container_asset_count(std::ptr::null()) },
            0
        );
        // SAFETY: null is explicitly documented as safe to free (a no-op).
        unsafe { gindema_container_free(std::ptr::null_mut()) }; // must not crash
    }
}
