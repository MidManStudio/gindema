// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/gindema-ffi.md, section "guard_ffi.rs"
// ============================================================================

//! C ABI over `gindema-guard`: a game's own native loop watching itself
//! for tampering. See `gindema_guard::{GuardState, Watch, TimingWindow,
//! Guarded}`'s own docs for what each one actually catches and doesn't —
//! this file only wraps them for C, it doesn't change what they do.

use std::panic::{catch_unwind, AssertUnwindSafe};
use std::slice;
use std::time::Duration;

use gindema_common::{checksum, checksums_match};
use gindema_guard::{GuardState, Guarded, TimingWindow, Watch};

use crate::status::{guard, GindemaStatus};

// ---------------------------------------------------------------------------
// GuardState
// ---------------------------------------------------------------------------

/// Opaque handle: see `gindema_guard_state_new`.
pub struct GindemaGuardState(GuardState);

/// Creates a fresh, clean guard state, shared by every `GindemaWatch`/
/// `GindemaGuarded*` that should pollute (and read from) the same flag.
/// Never fails — this is one atomic bool — so the result is never null.
///
/// Free with `gindema_guard_state_free`.
#[no_mangle]
pub extern "C" fn gindema_guard_state_new() -> *mut GindemaGuardState {
    Box::into_raw(Box::new(GindemaGuardState(GuardState::new())))
}

/// Whether `state` has been polluted by any watcher that shares it. `0`
/// (clean) if `state` is null, rather than a status code — there's no
/// failure mode here worth a negative return that wouldn't also look like
/// a plausible "clean" reading, so null is just treated as clean.
///
/// # Safety
/// `state`, if non-null, must be a live value `gindema_guard_state_new`
/// returned (not yet freed).
#[no_mangle]
pub unsafe extern "C" fn gindema_guard_state_is_polluted(state: *const GindemaGuardState) -> i32 {
    catch_unwind(AssertUnwindSafe(|| {
        if state.is_null() {
            0
        } else {
            // SAFETY: non-null, and live per the function's own contract.
            i32::from(unsafe { (*state).0.is_polluted() })
        }
    }))
    .unwrap_or(0)
}

/// Marks `state` polluted. Idempotent and permanent — see
/// `gindema_guard::GuardState::pollute`'s own docs for why there's no way
/// back. Returns a status code (`GindemaStatus::NullPointer` if `state` is
/// null) since, unlike reading, a caller pulling this trigger likely wants
/// to know it actually happened.
///
/// # Safety
/// `state` must be a live value `gindema_guard_state_new` returned.
#[no_mangle]
pub unsafe extern "C" fn gindema_guard_state_pollute(state: *mut GindemaGuardState) -> i32 {
    guard(|| {
        if state.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        // SAFETY: non-null, and live per the function's own contract.
        unsafe { (*state).0.pollute() };
        GindemaStatus::Ok.code()
    })
}

/// Frees a guard state. Safe to call with null (does nothing).
///
/// # Safety
/// `state`, if non-null, must be a live value `gindema_guard_state_new`
/// returned, and must not be used (including freed again) afterward.
#[no_mangle]
pub unsafe extern "C" fn gindema_guard_state_free(state: *mut GindemaGuardState) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if state.is_null() {
            return;
        }
        // used again after this (the caller's contract).
        // SAFETY: non-null, and live per the function's own contract; not
        let _ = unsafe { Box::from_raw(state) };
    }));
}

// ---------------------------------------------------------------------------
// TimingWindow
// ---------------------------------------------------------------------------

/// Opaque handle: see `gindema_timing_window_start`.
pub struct GindemaTimingWindow(TimingWindow);

/// Starts a new timing window, measured from now. Never fails.
///
/// Free with `gindema_timing_window_free`.
#[no_mangle]
pub extern "C" fn gindema_timing_window_start() -> *mut GindemaTimingWindow {
    Box::into_raw(Box::new(GindemaTimingWindow(TimingWindow::start())))
}

/// Milliseconds elapsed since `gindema_timing_window_start` was called —
/// always non-negative on success — or a negative `GindemaStatus` if
/// `window` is null.
///
/// # Safety
/// `window` must be a live value `gindema_timing_window_start` returned.
#[no_mangle]
pub unsafe extern "C" fn gindema_timing_window_elapsed_ms(
    window: *const GindemaTimingWindow,
) -> i64 {
    catch_unwind(AssertUnwindSafe(|| {
        if window.is_null() {
            return i64::from(GindemaStatus::NullPointer.code());
        }
        // SAFETY: non-null, and live per the function's own contract.
        let elapsed = unsafe { (*window).0.elapsed() };
        i64::try_from(elapsed.as_millis()).unwrap_or(i64::MAX)
    }))
    .unwrap_or(i64::from(GindemaStatus::InternalPanic.code()))
}

/// Whether the elapsed time is at or beyond `threshold_ms` — `1` or `0`,
/// or a negative `GindemaStatus` if `window` is null.
///
/// # Safety
/// `window` must be a live value `gindema_timing_window_start` returned.
#[no_mangle]
pub unsafe extern "C" fn gindema_timing_window_elapsed_at_least_ms(
    window: *const GindemaTimingWindow,
    threshold_ms: u64,
) -> i32 {
    catch_unwind(AssertUnwindSafe(|| {
        if window.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        let hit =
            // SAFETY: non-null, and live per the function's own contract.
            unsafe { (*window).0.elapsed_at_least(Duration::from_millis(threshold_ms)) };
        i32::from(hit)
    }))
    .unwrap_or(GindemaStatus::InternalPanic.code())
}

/// Frees a timing window. Safe to call with null.
///
/// # Safety
/// `window`, if non-null, must be a live value
/// `gindema_timing_window_start` returned, and must not be used (including
/// freed again) afterward.
#[no_mangle]
pub unsafe extern "C" fn gindema_timing_window_free(window: *mut GindemaTimingWindow) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if window.is_null() {
            return;
        }
        // used again after this (the caller's contract).
        // SAFETY: non-null, and live per the function's own contract; not
        let _ = unsafe { Box::from_raw(window) };
    }));
}

// ---------------------------------------------------------------------------
// Watch
// ---------------------------------------------------------------------------

/// Opaque handle: see `gindema_watch_new`.
pub struct GindemaWatch(Watch);

/// Records `data`'s current checksum as the expected one. Null only if
/// `data` is null while `len` is nonzero (an actually-empty region — `data`
/// null, `len` zero — is accepted and watched like any other).
///
/// # Safety
/// `data` must be valid for reads of `len` bytes, or null with `len == 0`.
#[no_mangle]
pub unsafe extern "C" fn gindema_watch_new(data: *const u8, len: usize) -> *mut GindemaWatch {
    let bytes: &[u8] = if data.is_null() {
        if len != 0 {
            return std::ptr::null_mut();
        }
        &[]
    } else {
        // SAFETY: non-null, and valid per the function's own contract.
        unsafe { slice::from_raw_parts(data, len) }
    };
    Box::into_raw(Box::new(GindemaWatch(Watch::new(bytes))))
}

/// Re-checksums `data` against what `watch` recorded at construction. `1`
/// on a match (leaves `state` untouched), `0` on a mismatch (pollutes
/// `state`), or a negative `GindemaStatus` if `watch` or `state` is null.
///
/// # Safety
/// `watch` and `state` must be live values from their respective
/// constructors. `data` must be valid for reads of `len` bytes, or null
/// with `len == 0`.
#[no_mangle]
pub unsafe extern "C" fn gindema_watch_check(
    watch: *const GindemaWatch,
    data: *const u8,
    len: usize,
    state: *const GindemaGuardState,
) -> i32 {
    guard(|| {
        if watch.is_null() || state.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        if data.is_null() && len != 0 {
            return GindemaStatus::NullPointer.code();
        }
        let bytes: &[u8] = if data.is_null() {
            &[]
        } else {
            // SAFETY: non-null, and valid per the function's own contract.
            unsafe { slice::from_raw_parts(data, len) }
        };
        // SAFETY: both non-null, and live per the function's own contract.
        let matches = unsafe { (*watch).0.check(bytes, &(*state).0) };
        i32::from(matches)
    })
}

/// Frees a watch. Safe to call with null.
///
/// # Safety
/// `watch`, if non-null, must be a live value `gindema_watch_new`
/// returned, and must not be used (including freed again) afterward.
#[no_mangle]
pub unsafe extern "C" fn gindema_watch_free(watch: *mut GindemaWatch) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if watch.is_null() {
            return;
        }
        // used again after this (the caller's contract).
        // SAFETY: non-null, and live per the function's own contract; not
        let _ = unsafe { Box::from_raw(watch) };
    }));
}

// ---------------------------------------------------------------------------
// Guarded<i64> / Guarded<f64>
//
// gindema_guard::Guarded<T> is generic; C has no equivalent, so this
// exposes the two concrete instantiations a game's values are realistically
// ever going to need (an integer stat -- gold, score, ammo -- or a float
// one -- health, a timer). Written out twice rather than macro-generated:
// each is short, and a reader grepping for "guarded_i64" shouldn't have to
// also understand a macro to see what it does.
// ---------------------------------------------------------------------------

/// Opaque handle: see `gindema_guarded_i64_new`.
pub struct GindemaGuardedI64(Guarded<i64>);

/// Wraps `real`, falling back to `decoy` once a `GindemaGuardState` it's
/// read against (via `gindema_guarded_i64_read`) is polluted. Never fails.
///
/// Free with `gindema_guarded_i64_free`.
#[no_mangle]
pub extern "C" fn gindema_guarded_i64_new(real: i64, decoy: i64) -> *mut GindemaGuardedI64 {
    Box::into_raw(Box::new(GindemaGuardedI64(Guarded::new(real, decoy))))
}

/// Writes the real value to `*out_value` if `state` is clean, the decoy if
/// polluted.
///
/// # Safety
/// `guarded` and `state` must be live values from their respective
/// constructors. `out_value` must be valid for writes of one `int64_t`.
#[no_mangle]
pub unsafe extern "C" fn gindema_guarded_i64_read(
    guarded: *const GindemaGuardedI64,
    state: *const GindemaGuardState,
    out_value: *mut i64,
) -> i32 {
    guard(|| {
        if guarded.is_null() || state.is_null() || out_value.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        // SAFETY: both non-null, and live per the function's own contract.
        let value = unsafe { (*guarded).0.read(&(*state).0) };
        // contract.
        // SAFETY: non-null, and valid for one write per the function's own
        unsafe { *out_value = value };
        GindemaStatus::Ok.code()
    })
}

/// Frees a guarded i64. Safe to call with null.
///
/// # Safety
/// `guarded`, if non-null, must be a live value `gindema_guarded_i64_new`
/// returned, and must not be used (including freed again) afterward.
#[no_mangle]
pub unsafe extern "C" fn gindema_guarded_i64_free(guarded: *mut GindemaGuardedI64) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if guarded.is_null() {
            return;
        }
        // used again after this (the caller's contract).
        // SAFETY: non-null, and live per the function's own contract; not
        let _ = unsafe { Box::from_raw(guarded) };
    }));
}

/// Opaque handle: see `gindema_guarded_f64_new`.
pub struct GindemaGuardedF64(Guarded<f64>);

/// Wraps `real`, falling back to `decoy` once a `GindemaGuardState` it's
/// read against (via `gindema_guarded_f64_read`) is polluted. Never fails.
///
/// Free with `gindema_guarded_f64_free`.
#[no_mangle]
pub extern "C" fn gindema_guarded_f64_new(real: f64, decoy: f64) -> *mut GindemaGuardedF64 {
    Box::into_raw(Box::new(GindemaGuardedF64(Guarded::new(real, decoy))))
}

/// Writes the real value to `*out_value` if `state` is clean, the decoy if
/// polluted.
///
/// # Safety
/// `guarded` and `state` must be live values from their respective
/// constructors. `out_value` must be valid for writes of one `double`.
#[no_mangle]
pub unsafe extern "C" fn gindema_guarded_f64_read(
    guarded: *const GindemaGuardedF64,
    state: *const GindemaGuardState,
    out_value: *mut f64,
) -> i32 {
    guard(|| {
        if guarded.is_null() || state.is_null() || out_value.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        // SAFETY: both non-null, and live per the function's own contract.
        let value = unsafe { (*guarded).0.read(&(*state).0) };
        // contract.
        // SAFETY: non-null, and valid for one write per the function's own
        unsafe { *out_value = value };
        GindemaStatus::Ok.code()
    })
}

/// Frees a guarded f64. Safe to call with null.
///
/// # Safety
/// `guarded`, if non-null, must be a live value `gindema_guarded_f64_new`
/// returned, and must not be used (including freed again) afterward.
#[no_mangle]
pub unsafe extern "C" fn gindema_guarded_f64_free(guarded: *mut GindemaGuardedF64) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if guarded.is_null() {
            return;
        }
        // used again after this (the caller's contract).
        // SAFETY: non-null, and live per the function's own contract; not
        let _ = unsafe { Box::from_raw(guarded) };
    }));
}

// ---------------------------------------------------------------------------
// Checksum (what Watch uses internally; exposed directly too, for a caller
// that wants to manage the "expected value" itself, e.g. storing one in
// its own save-file format rather than keeping a GindemaWatch alive).
// ---------------------------------------------------------------------------

/// Computes `data`'s FNV-1a checksum (the same one `gindema_watch_new`
/// uses) and writes it to `*out`.
///
/// # Safety
/// `data` must be valid for reads of `len` bytes, or null with `len == 0`.
/// `out` must be valid for writes of one `uint64_t`.
#[no_mangle]
pub unsafe extern "C" fn gindema_checksum(data: *const u8, len: usize, out: *mut u64) -> i32 {
    guard(|| {
        if out.is_null() {
            return GindemaStatus::NullPointer.code();
        }
        if data.is_null() && len != 0 {
            return GindemaStatus::NullPointer.code();
        }
        let bytes: &[u8] = if data.is_null() {
            &[]
        } else {
            // SAFETY: non-null, and valid per the function's own contract.
            unsafe { slice::from_raw_parts(data, len) }
        };
        let value = checksum(bytes);
        // contract.
        // SAFETY: non-null, and valid for one write per the function's own
        unsafe { *out = value };
        GindemaStatus::Ok.code()
    })
}

/// Whether two checksums match — a trivial `==`, exposed for symmetry with
/// `gindema_checksum` and because `gindema_common::checksums_match` is its
/// own documented function in the Rust API this mirrors, not just `==`
/// inlined at every call site.
#[no_mangle]
pub extern "C" fn gindema_checksums_match(a: u64, b: u64) -> i32 {
    i32::from(checksums_match(a, b))
}

#[cfg(test)]
mod tests {
    use super::*;

    // Every call below goes through this crate's own `#[no_mangle]`
    // functions with handles this same test just created (or a
    // deliberately null one, for the null-handling tests), so each
    // call satisfies the exact contract documented on that function
    // above -- restated tersely at each site rather than copied in
    // full, since `undocumented_unsafe_blocks` is enforced here too
    // (see Cargo.toml's lint override: `unsafe_code` is allowed for
    // this one crate, nothing else is relaxed).

    #[test]
    fn guard_state_round_trips_clean_then_polluted() {
        let state = gindema_guard_state_new();
        // SAFETY: state is a live value gindema_guard_state_new just returned.
        assert_eq!(unsafe { gindema_guard_state_is_polluted(state) }, 0);
        assert_eq!(
            // SAFETY: state is a live value gindema_guard_state_new just returned.
            unsafe { gindema_guard_state_pollute(state) },
            GindemaStatus::Ok.code()
        );
        // SAFETY: state is a live value gindema_guard_state_new just returned.
        assert_eq!(unsafe { gindema_guard_state_is_polluted(state) }, 1);
        // SAFETY: state is live and not used again after this call.
        unsafe { gindema_guard_state_free(state) };
    }

    #[test]
    fn guard_state_null_pointer_handling() {
        assert_eq!(
            // SAFETY: null is an explicitly documented, accepted input here.
            unsafe { gindema_guard_state_is_polluted(std::ptr::null()) },
            0
        );
        assert_eq!(
            // SAFETY: null is an explicitly documented, accepted input here.
            unsafe { gindema_guard_state_pollute(std::ptr::null_mut()) },
            GindemaStatus::NullPointer.code()
        );
        // SAFETY: null is explicitly documented as safe to free (a no-op).
        unsafe { gindema_guard_state_free(std::ptr::null_mut()) }; // must not crash
    }

    #[test]
    fn timing_window_elapsed_is_non_negative_and_grows() {
        let window = gindema_timing_window_start();
        // SAFETY: window is a live value gindema_timing_window_start just returned.
        let first = unsafe { gindema_timing_window_elapsed_ms(window) };
        assert!(first >= 0);
        std::thread::sleep(Duration::from_millis(20));
        // SAFETY: window is still live.
        let second = unsafe { gindema_timing_window_elapsed_ms(window) };
        assert!(second >= first);
        assert_eq!(
            // SAFETY: window is still live.
            unsafe { gindema_timing_window_elapsed_at_least_ms(window, 5) },
            1
        );
        assert_eq!(
            // SAFETY: window is still live.
            unsafe { gindema_timing_window_elapsed_at_least_ms(window, 10_000) },
            0
        );
        // SAFETY: window is live and not used again after this call.
        unsafe { gindema_timing_window_free(window) };
    }

    #[test]
    fn timing_window_null_pointer_handling() {
        assert_eq!(
            // SAFETY: null is an explicitly documented, accepted input here.
            unsafe { gindema_timing_window_elapsed_ms(std::ptr::null()) },
            i64::from(GindemaStatus::NullPointer.code())
        );
        assert_eq!(
            // SAFETY: null is an explicitly documented, accepted input here.
            unsafe { gindema_timing_window_elapsed_at_least_ms(std::ptr::null(), 1) },
            GindemaStatus::NullPointer.code()
        );
    }

    #[test]
    fn watch_detects_unchanged_vs_changed_data() {
        let data = [1u8, 2, 3, 4, 5];
        // SAFETY: data points to data.len() valid, initialized bytes.
        let watch = unsafe { gindema_watch_new(data.as_ptr(), data.len()) };
        assert!(!watch.is_null());
        let state = gindema_guard_state_new();

        assert_eq!(
            // SAFETY: watch and state are both live; data is valid as above.
            unsafe { gindema_watch_check(watch, data.as_ptr(), data.len(), state) },
            1
        );
        // SAFETY: state is live.
        assert_eq!(unsafe { gindema_guard_state_is_polluted(state) }, 0);

        let changed = [1u8, 2, 99, 4, 5];
        assert_eq!(
            // SAFETY: watch and state are both live; changed is valid for its own length.
            unsafe { gindema_watch_check(watch, changed.as_ptr(), changed.len(), state) },
            0
        );
        // SAFETY: state is live.
        assert_eq!(unsafe { gindema_guard_state_is_polluted(state) }, 1);

        // SAFETY: both handles are live and not used again after these calls.
        unsafe {
            gindema_watch_free(watch);
            gindema_guard_state_free(state);
        }
    }

    #[test]
    fn watch_accepts_a_genuinely_empty_region() {
        // SAFETY: null with len 0 is an explicitly documented, accepted input.
        let watch = unsafe { gindema_watch_new(std::ptr::null(), 0) };
        assert!(!watch.is_null());
        let state = gindema_guard_state_new();
        assert_eq!(
            // SAFETY: watch and state are live; null with len 0 is accepted for data too.
            unsafe { gindema_watch_check(watch, std::ptr::null(), 0, state) },
            1
        );
        // SAFETY: both handles are live and not used again after these calls.
        unsafe {
            gindema_watch_free(watch);
            gindema_guard_state_free(state);
        }
    }

    #[test]
    fn watch_new_rejects_null_data_with_nonzero_len() {
        // SAFETY: a null/nonzero-len combination is documented to return null, not UB.
        let watch = unsafe { gindema_watch_new(std::ptr::null(), 4) };
        assert!(watch.is_null());
    }

    #[test]
    fn guarded_i64_switches_to_decoy_once_polluted() {
        let guarded = gindema_guarded_i64_new(500, -1);
        let state = gindema_guard_state_new();
        let mut out = 0i64;

        assert_eq!(
            // SAFETY: guarded and state are live; out_value is a valid write target.
            unsafe { gindema_guarded_i64_read(guarded, state, &mut out) },
            GindemaStatus::Ok.code()
        );
        assert_eq!(out, 500);

        // SAFETY: state is live.
        unsafe { gindema_guard_state_pollute(state) };
        assert_eq!(
            // SAFETY: guarded and state are live; out_value is a valid write target.
            unsafe { gindema_guarded_i64_read(guarded, state, &mut out) },
            GindemaStatus::Ok.code()
        );
        assert_eq!(out, -1);

        // SAFETY: both handles are live and not used again after these calls.
        unsafe {
            gindema_guarded_i64_free(guarded);
            gindema_guard_state_free(state);
        }
    }

    #[test]
    fn guarded_f64_switches_to_decoy_once_polluted() {
        let guarded = gindema_guarded_f64_new(100.0, -1.0);
        let state = gindema_guard_state_new();
        let mut out = 0.0f64;

        // SAFETY: guarded and state are live; out_value is a valid write target.
        unsafe { gindema_guarded_f64_read(guarded, state, &mut out) };
        assert_eq!(out, 100.0);

        // SAFETY: state is live.
        unsafe { gindema_guard_state_pollute(state) };
        // SAFETY: guarded and state are live; out_value is a valid write target.
        unsafe { gindema_guarded_f64_read(guarded, state, &mut out) };
        assert_eq!(out, -1.0);

        // SAFETY: both handles are live and not used again after these calls.
        unsafe {
            gindema_guarded_f64_free(guarded);
            gindema_guard_state_free(state);
        }
    }

    #[test]
    fn checksum_matches_the_watch_it_backs() {
        let data = [9u8, 8, 7];
        let mut a = 0u64;
        let mut b = 0u64;
        // SAFETY: data is valid for its own length; a/b are valid write targets.
        unsafe {
            gindema_checksum(data.as_ptr(), data.len(), &mut a);
            gindema_checksum(data.as_ptr(), data.len(), &mut b);
        }
        assert_eq!(gindema_checksums_match(a, b), 1);

        let other = [1u8, 2, 3];
        let mut c = 0u64;
        // SAFETY: other is valid for its own length; c is a valid write target.
        unsafe { gindema_checksum(other.as_ptr(), other.len(), &mut c) };
        assert_eq!(gindema_checksums_match(a, c), 0);
    }
}
