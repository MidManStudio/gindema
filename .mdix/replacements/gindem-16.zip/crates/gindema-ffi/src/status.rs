// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/gindema-ffi.md, section "status.rs"
// ============================================================================

use std::panic::{catch_unwind, AssertUnwindSafe};

use gindema_container::ContainerError;

/// Status codes every `gindema_*` function that can fail returns. A
/// non-negative return from one of those functions is a byte count or a
/// boolean (0/1), documented per function in `gindema.h`; a negative one is
/// always one of these.
///
/// The first four carry the same numbers mid-engine's own `mid_net.h`/
/// `mid_net_quic.h` use for the equivalent cases (`Ok` 0, `NullPointer` -1,
/// `BufferTooSmall` -2, `InternalPanic` -6) — not required for correctness,
/// since these are two unrelated status enums a caller would never compare
/// directly, but a native game likely to link both (`docs/gindema-ffi.md`'s
/// Overview covers that case) sees one convention instead of two. Codes
/// this crate needed that mid-engine's didn't start at -20, leaving room
/// between the two without implying a relationship that isn't there.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GindemaStatus {
    /// Success.
    Ok = 0,
    /// A required pointer argument was null.
    NullPointer = -1,
    /// An output buffer was too small to hold the result; nothing was
    /// written to it.
    BufferTooSmall = -2,
    /// Something inside this crate panicked. Exists so a caller gets a
    /// code, not a panic unwinding across the C boundary (which is
    /// undefined behavior) -- see [`guard`].
    InternalPanic = -6,
    /// [`gindema_container_key_from_base64`]: not valid base64, or didn't
    /// decode to exactly 32 bytes.
    InvalidKey = -20,
    /// [`crate::container_ffi::gindema_container_open`]: the archive
    /// didn't start with the expected magic bytes.
    InvalidMagic = -21,
    /// The archive declared a format version this build doesn't read.
    UnsupportedVersion = -22,
    /// The archive ended before a complete header, index, or slot could be
    /// read.
    UnexpectedEof = -23,
    /// The decrypted index didn't parse as a valid slot list.
    CorruptIndex = -24,
    /// No slot in the archive holds the requested asset order.
    InvalidAssetId = -25,
    /// Decryption failed: the wrong key, or a corrupted/tampered archive
    /// (AES-GCM is authenticated, so these aren't distinguishable from the
    /// failure alone -- same caveat as [`gindema_container::ContainerError::Decrypt`]).
    DecryptFailed = -26,
    /// Decompression failed -- a corrupted archive, most likely.
    DecompressFailed = -27,
}

impl GindemaStatus {
    /// This status as the `i32` a `gindema_*` function actually returns.
    pub(crate) fn code(self) -> i32 {
        self as i32
    }
}

/// Maps the subset of [`ContainerError`] that [`crate::container_ffi`]'s
/// read-only surface can actually produce (opening an archive and reading
/// an asset from it -- never building one, which this crate doesn't expose
/// at all; see `docs/gindema-ffi.md`'s Overview for why) to a
/// [`GindemaStatus`]. The build-only variants
/// (`EmptyAsset`/`Compress`/`Encrypt`) have no case here on purpose: they
/// can't be reached through this crate's API, so mapping them would be
/// untestable dead code.
impl From<ContainerError> for GindemaStatus {
    fn from(e: ContainerError) -> Self {
        match e {
            ContainerError::InvalidKey(_) => Self::InvalidKey,
            ContainerError::InvalidMagic => Self::InvalidMagic,
            ContainerError::UnsupportedVersion(_) => Self::UnsupportedVersion,
            ContainerError::UnexpectedEof => Self::UnexpectedEof,
            ContainerError::CorruptIndex => Self::CorruptIndex,
            ContainerError::InvalidAssetId(_) => Self::InvalidAssetId,
            ContainerError::Decrypt(_) => Self::DecryptFailed,
            ContainerError::Decompress(_) => Self::DecompressFailed,
            // EmptyAsset/Compress/Encrypt: builder-only, unreachable here.
            ContainerError::EmptyAsset
            | ContainerError::Compress(_)
            | ContainerError::Encrypt(_) => {
                unreachable!(
                    "builder-only ContainerError variants can't be produced by this crate's \
                     read-only container_ffi surface"
                )
            }
        }
    }
}

/// Runs `f`, turning a panic into [`GindemaStatus::InternalPanic`] instead
/// of letting it unwind across the C boundary (undefined behavior). Every
/// `gindema_*` function that returns a status code goes through this; one
/// returning some other type (a count, a pointer, a bare bool) uses
/// [`catch_unwind`] directly with its own fallback value instead.
pub(crate) fn guard(f: impl FnOnce() -> i32) -> i32 {
    catch_unwind(AssertUnwindSafe(f)).unwrap_or(GindemaStatus::InternalPanic.code())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shared_codes_match_mid_engines_convention() {
        assert_eq!(GindemaStatus::Ok.code(), 0);
        assert_eq!(GindemaStatus::NullPointer.code(), -1);
        assert_eq!(GindemaStatus::BufferTooSmall.code(), -2);
        assert_eq!(GindemaStatus::InternalPanic.code(), -6);
    }

    #[test]
    fn guard_turns_a_panic_into_internal_panic_not_an_unwind() {
        let result = guard(|| panic!("deliberate, for this test"));
        assert_eq!(result, GindemaStatus::InternalPanic.code());
    }

    #[test]
    fn guard_passes_through_an_ordinary_return_value() {
        assert_eq!(guard(|| GindemaStatus::Ok.code()), 0);
    }

    #[test]
    fn every_reachable_container_error_maps_to_a_distinct_status() {
        let cases = [
            (
                ContainerError::InvalidKey(String::new()),
                GindemaStatus::InvalidKey,
            ),
            (ContainerError::InvalidMagic, GindemaStatus::InvalidMagic),
            (
                ContainerError::UnsupportedVersion(1),
                GindemaStatus::UnsupportedVersion,
            ),
            (ContainerError::UnexpectedEof, GindemaStatus::UnexpectedEof),
            (ContainerError::CorruptIndex, GindemaStatus::CorruptIndex),
            (
                ContainerError::InvalidAssetId(0),
                GindemaStatus::InvalidAssetId,
            ),
            (
                ContainerError::Decrypt(String::new()),
                GindemaStatus::DecryptFailed,
            ),
            (
                ContainerError::Decompress(String::new()),
                GindemaStatus::DecompressFailed,
            ),
        ];
        for (err, expected) in cases {
            assert_eq!(GindemaStatus::from(err), expected);
        }
    }
}
