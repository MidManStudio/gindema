// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/gindema-ffi.md, section "lib.rs"
// ============================================================================

//! C ABI over `gindema-guard` (runtime anti-tamper) and `gindema-container`
//! (encrypted asset reading) — the first FFI surface this workspace has
//! had, for a native game written in C, C#, or anything else that can link
//! a C library. One consolidated library (`gindema`, `gindema.h`) covering
//! both, deliberately, rather than one per crate — see "Why one library"
//! below.
//!
//! `gindema-vm` (running obfuscated bytecode) has no FFI surface here yet:
//! which specific routine a game would want to protect that way is a
//! design decision for whoever's integrating it, not one this crate should
//! make unilaterally. `gindema-obfuscate`'s four passes run at build time
//! (already reachable through `gindema-cli`'s `flatten`/`fluff`/`remap`),
//! not at runtime, so they have no FFI surface either, by design, not by
//! omission.
//!
//! # Why one library
//! A native program can link exactly one Rust `staticlib`'s worth of
//! `std`/`core`/`compiler_builtins` symbols — a second one brings its own
//! copies and the linker meets every one of them twice. Tower of
//! Babylon (`docs/android.md`/`docs/net.md` in that repo) already links
//! one Rust static library this way (mid-engine's `mid_net_quic`), built
//! with `cargo rustc --crate-type staticlib`. If this crate shipped as
//! several separate FFI crates the way `gindema-vm`/`gindema-obfuscate`/
//! `gindema-guard`/`gindema-container` are separate Rust libraries, a game
//! wanting more than one of them as `staticlib`s would hit exactly that
//! conflict — the same reason mid-engine's own
//! `mid-net-transport-quinn-ffi` absorbs its facade crate's driver/server
//! FFI into one library instead of two. Consolidating `gindema-guard` and
//! `gindema-container` here now, with room for `gindema-vm` later, avoids
//! ever creating that problem on this side. **Still open:** a native
//! program wanting both `mid_net_quic` *and* `gindema` as `staticlib`s
//! would still hit it between the two projects — see
//! `docs/gindema-ffi.md`'s "Known limits" for why this crate also builds
//! as a `cdylib`, which sidesteps it (a `cdylib`'s symbols resolve at
//! runtime, not at the static link step), and isn't solved any more deeply
//! than that yet.
//!
//! # Conventions (see `gindema.h`, hand-written to match this crate
//! exactly rather than `cbindgen`-generated, same as mid-engine's own
//! headers for the same reason: a human reviewing the actual C-visible
//! contract line by line catches more than a generator would)
//! - Every function that can fail returns a `GindemaStatus` (`0` success,
//!   negative a specific failure) or a non-negative byte count; one that
//!   can't fail returns its value, or a pointer, directly.
//! - Every function taking a raw pointer is `unsafe` with a `# Safety`
//!   contract, and checks every pointer for null before doing anything
//!   else with it.
//! - Every function body runs inside a panic guard
//!   ([`status::guard`]/[`std::panic::catch_unwind`] directly for
//!   non-`i32` returns): a panic becomes [`status::GindemaStatus::InternalPanic`],
//!   never an unwind across the C boundary (undefined behavior).
//! - Stateful things are opaque handles, made with a `_new`/`_open`
//!   function and freed with a matching `_free` function that accepts
//!   null safely.

mod container_ffi;
mod guard_ffi;
mod status;

pub use container_ffi::{
    gindema_container_asset_count, gindema_container_free, gindema_container_key_from_base64,
    gindema_container_open, gindema_container_read_asset, gindema_container_read_asset_len,
    GindemaContainerReader, GINDEMA_CONTAINER_KEY_LEN,
};
pub use guard_ffi::{
    gindema_checksum, gindema_checksums_match, gindema_guard_state_free,
    gindema_guard_state_is_polluted, gindema_guard_state_new, gindema_guard_state_pollute,
    gindema_guarded_f64_free, gindema_guarded_f64_new, gindema_guarded_f64_read,
    gindema_guarded_i64_free, gindema_guarded_i64_new, gindema_guarded_i64_read,
    gindema_timing_window_elapsed_at_least_ms, gindema_timing_window_elapsed_ms,
    gindema_timing_window_free, gindema_timing_window_start, gindema_watch_check,
    gindema_watch_free, gindema_watch_new, GindemaGuardState, GindemaGuardedF64, GindemaGuardedI64,
    GindemaTimingWindow, GindemaWatch,
};
pub use status::GindemaStatus;
