/*
 * gindema.h -- C ABI over gindema-guard (runtime anti-tamper) and
 * gindema-container (encrypted asset reading).
 *
 * Hand-written to match crates/gindema-ffi/src/ (lib.rs, status.rs,
 * guard_ffi.rs, container_ffi.rs) exactly, the same way
 * mid-engine's own mid_net_quic.h is hand-written rather than
 * cbindgen-generated: a human reviewing the actual C-visible contract line
 * by line catches more than a generator would. See docs/gindema-ffi.md for
 * the full design.
 *
 * Link against libgindema.a (static) or libgindema.so (dynamic) -- both are
 * built from the same crate, crate-type = ["staticlib", "cdylib"]. Pick
 * static unless you specifically need two independent Rust static
 * libraries in the same program (see docs/gindema-ffi.md's "Known limits"
 * for why that needs the dynamic form instead).
 */

#ifndef GINDEMA_H
#define GINDEMA_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------------------------------------------------------------
 * Status codes. A non-negative return from a function documented below
 * as returning one of these is success (and, where noted, also the
 * actual result -- a byte count, a boolean 0/1); a negative one is
 * always one of these codes.
 *
 * The first four match mid-engine's own mid_net.h/mid_net_quic.h numbers
 * for the same cases -- not required for correctness (these are two
 * unrelated status spaces), but convenient if your program links both.
 * ------------------------------------------------------------------- */
#define GINDEMA_OK                   0
#define GINDEMA_NULL_POINTER        -1
#define GINDEMA_BUFFER_TOO_SMALL    -2
#define GINDEMA_INTERNAL_PANIC      -6

#define GINDEMA_INVALID_KEY           -20 /* bad base64, or not 32 bytes decoded */
#define GINDEMA_INVALID_MAGIC         -21 /* archive doesn't start with the right magic bytes */
#define GINDEMA_UNSUPPORTED_VERSION   -22 /* archive format version this build can't read */
#define GINDEMA_UNEXPECTED_EOF        -23 /* archive ended before a complete header/index/slot */
#define GINDEMA_CORRUPT_INDEX         -24 /* decrypted index didn't parse as a valid slot list */
#define GINDEMA_INVALID_ASSET_ID      -25 /* no slot holds the requested asset order */
#define GINDEMA_DECRYPT_FAILED        -26 /* wrong key, or corrupted/tampered archive */
#define GINDEMA_DECOMPRESS_FAILED     -27 /* corrupted archive, most likely */

/* =======================================================================
 * gindema-guard: runtime anti-tamper primitives for a game's own native
 * loop. See gindema_guard's own Rust docs for what each one actually
 * catches and doesn't -- this header only wraps them for C.
 * ===================================================================== */

/* --- GindemaGuardState: one shared, sticky, one-way pollution flag. --- */

typedef struct GindemaGuardState GindemaGuardState;

/* Creates a fresh, clean guard state, shared by every Watch/Guarded that
 * should pollute (and read from) the same flag. Never fails; never NULL.
 * Free with gindema_guard_state_free. */
GindemaGuardState *gindema_guard_state_new(void);

/* Whether `state` has been polluted. 0 (clean) if `state` is NULL. */
int gindema_guard_state_is_polluted(const GindemaGuardState *state);

/* Marks `state` polluted. Idempotent and permanent -- there is no way
 * back. Returns GINDEMA_OK, or GINDEMA_NULL_POINTER if `state` is NULL. */
int gindema_guard_state_pollute(GindemaGuardState *state);

/* Frees a guard state. Safe to call with NULL (does nothing). `state`
 * must not be used again afterward. */
void gindema_guard_state_free(GindemaGuardState *state);

/* --- GindemaTimingWindow: elapsed-time / debugger-pause signal. --- */

typedef struct GindemaTimingWindow GindemaTimingWindow;

/* Starts a new timing window, measured from now. Never fails; never
 * NULL. Free with gindema_timing_window_free. */
GindemaTimingWindow *gindema_timing_window_start(void);

/* Milliseconds elapsed since start (always >= 0 on success), or a
 * negative status (GINDEMA_NULL_POINTER) if `window` is NULL. */
int64_t gindema_timing_window_elapsed_ms(const GindemaTimingWindow *window);

/* 1 or 0: whether the elapsed time is at or beyond threshold_ms. A
 * negative status (GINDEMA_NULL_POINTER) if `window` is NULL. */
int gindema_timing_window_elapsed_at_least_ms(
    const GindemaTimingWindow *window,
    uint64_t threshold_ms
);

/* Frees a timing window. Safe to call with NULL. `window` must not be
 * used again afterward. */
void gindema_timing_window_free(GindemaTimingWindow *window);

/* --- GindemaWatch: checksum a region now, re-check it later. --- */

typedef struct GindemaWatch GindemaWatch;

/* Records data[0..len)'s checksum as the expected one. `data` may be
 * NULL only if `len` is 0 (a real empty region, accepted like any
 * other). Returns NULL if `data` is NULL while `len` is nonzero.
 * Free with gindema_watch_free. */
GindemaWatch *gindema_watch_new(const uint8_t *data, size_t len);

/* Re-checksums data[0..len) against what `watch` recorded at
 * construction. 1 on a match (leaves `state` untouched), 0 on a
 * mismatch (pollutes `state`), or a negative status
 * (GINDEMA_NULL_POINTER) if `watch` or `state` is NULL, or if `data` is
 * NULL while `len` is nonzero. */
int gindema_watch_check(
    const GindemaWatch *watch,
    const uint8_t *data,
    size_t len,
    const GindemaGuardState *state
);

/* Frees a watch. Safe to call with NULL. `watch` must not be used again
 * afterward. */
void gindema_watch_free(GindemaWatch *watch);

/* --- GindemaGuardedI64 / GindemaGuardedF64: a value with a decoy
 * fallback once its guard state is polluted. --- */

typedef struct GindemaGuardedI64 GindemaGuardedI64;
typedef struct GindemaGuardedF64 GindemaGuardedF64;

/* Wraps `real`, falling back to `decoy` once the state it's read against
 * is polluted. Never fails; never NULL. Free with the matching _free. */
GindemaGuardedI64 *gindema_guarded_i64_new(int64_t real, int64_t decoy);
GindemaGuardedF64 *gindema_guarded_f64_new(double real, double decoy);

/* Writes the real value to *out_value if `state` is clean, the decoy if
 * polluted. Returns GINDEMA_OK, or GINDEMA_NULL_POINTER if any argument
 * is NULL. */
int gindema_guarded_i64_read(
    const GindemaGuardedI64 *guarded,
    const GindemaGuardState *state,
    int64_t *out_value
);
int gindema_guarded_f64_read(
    const GindemaGuardedF64 *guarded,
    const GindemaGuardState *state,
    double *out_value
);

/* Frees a guarded value. Safe to call with NULL. Must not be used again
 * afterward. */
void gindema_guarded_i64_free(GindemaGuardedI64 *guarded);
void gindema_guarded_f64_free(GindemaGuardedF64 *guarded);

/* --- Checksum: what Watch uses internally, exposed directly too. --- */

/* Computes data[0..len)'s FNV-1a checksum (the same one GindemaWatch
 * uses) and writes it to *out. Returns GINDEMA_OK, or
 * GINDEMA_NULL_POINTER if `out` is NULL, or `data` is NULL while `len`
 * is nonzero. */
int gindema_checksum(const uint8_t *data, size_t len, uint64_t *out);

/* Whether two checksums match -- a trivial ==, kept as its own function
 * for symmetry with gindema_checksum. Always 1 or 0. */
int gindema_checksums_match(uint64_t a, uint64_t b);

/* =======================================================================
 * gindema-container: read-only access to an encrypted asset archive
 * (built ahead of time with `gindema-cli pack`). Building an archive is
 * not exposed here -- a shipped game only ever reads one.
 * ===================================================================== */

#define GINDEMA_CONTAINER_KEY_LEN 32

/* Parses a base64-encoded key (the form `gindema-cli pack` prints) and
 * writes the 32 raw key bytes to out_key. GINDEMA_INVALID_KEY if
 * `base64` isn't valid base64 or doesn't decode to exactly 32 bytes --
 * nothing is written to out_key in that case. */
int gindema_container_key_from_base64(const char *base64, uint8_t out_key[GINDEMA_CONTAINER_KEY_LEN]);

typedef struct GindemaContainerReader GindemaContainerReader;

/* Copies data/key, opens the archive once to validate it, and writes a
 * handle to *out on success. `key` must point to exactly
 * GINDEMA_CONTAINER_KEY_LEN readable bytes. On any non-OK return, *out
 * is left unset (NULL on the first call per the usual C convention of
 * zero-initializing it yourself first).
 * Free a successfully-opened reader with gindema_container_free. */
int gindema_container_open(
    const uint8_t *data,
    size_t data_len,
    const uint8_t key[GINDEMA_CONTAINER_KEY_LEN],
    GindemaContainerReader **out
);

/* How many real assets the archive holds (honeypot slots don't count).
 * 0 if `reader` is NULL. */
uint32_t gindema_container_asset_count(const GindemaContainerReader *reader);

/* The byte length of asset `asset_order`, so you can allocate a buffer
 * of exactly that size before calling gindema_container_read_asset.
 * Always non-negative on success, or a negative status
 * (GINDEMA_INVALID_ASSET_ID if no slot holds that order). */
int64_t gindema_container_read_asset_len(const GindemaContainerReader *reader, uint32_t asset_order);

/* Decrypts and decompresses asset `asset_order` into buf[0..cap).
 * Returns the number of bytes written (always non-negative) on success;
 * GINDEMA_BUFFER_TOO_SMALL if cap is smaller than the asset's real
 * length (nothing is written in that case -- call
 * gindema_container_read_asset_len first to size buf exactly); or
 * another negative status for a bad asset_order or a corrupted/
 * wrong-keyed archive. */
int64_t gindema_container_read_asset(
    const GindemaContainerReader *reader,
    uint32_t asset_order,
    uint8_t *buf,
    size_t cap
);

/* Frees a container reader. Safe to call with NULL. `reader` must not be
 * used again afterward. */
void gindema_container_free(GindemaContainerReader *reader);

#ifdef __cplusplus
}
#endif

#endif /* GINDEMA_H */
