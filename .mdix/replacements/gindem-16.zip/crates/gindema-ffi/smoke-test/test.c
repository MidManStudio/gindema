// crates/gindema-ffi/smoke-test/test.c
//
// A real C program exercising gindema.h: guard-state pollution, a timing
// window, a watch catching tampering, guarded i64/f64 values falling back
// to their decoys, checksums, and reading a real archive (fixture.gctn,
// built by `gindema-cli pack` -- a cross-check that the CLI's output and
// this FFI's reading are actually interoperable, not just each tested in
// isolation). Build and run against both library forms (see the bottom of
// this file); exit code 0 only if every check passed.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gindema.h"

static int g_failed = 0, g_checks = 0;
#define CHECK(cond, what)                                                    \
    do {                                                                     \
        ++g_checks;                                                          \
        if (!(cond)) {                                                       \
            printf("  [FAIL] %s (line %d)\n", what, __LINE__);               \
            ++g_failed;                                                      \
        } else {                                                             \
            printf("  [pass] %s\n", what);                                   \
        }                                                                    \
    } while (0)

static void check_guard_state(void) {
    printf("-- guard state --\n");
    GindemaGuardState *state = gindema_guard_state_new();
    CHECK(state != NULL, "a guard state is created");
    CHECK(gindema_guard_state_is_polluted(state) == 0, "starts clean");
    CHECK(gindema_guard_state_pollute(state) == GINDEMA_OK, "pollute succeeds");
    CHECK(gindema_guard_state_is_polluted(state) == 1, "and is now polluted");
    CHECK(gindema_guard_state_pollute(NULL) == GINDEMA_NULL_POINTER, "pollute(NULL) is refused");
    gindema_guard_state_free(state);
    gindema_guard_state_free(NULL); /* must not crash */
}

static void check_timing_window(void) {
    printf("-- timing window --\n");
    GindemaTimingWindow *w = gindema_timing_window_start();
    CHECK(w != NULL, "a timing window is created");
    int64_t ms = gindema_timing_window_elapsed_ms(w);
    CHECK(ms >= 0, "elapsed time is non-negative");
    CHECK(gindema_timing_window_elapsed_at_least_ms(w, 0) == 1, "0ms threshold always met");
    CHECK(gindema_timing_window_elapsed_at_least_ms(w, 60000) == 0, "a minute has not passed");
    CHECK(gindema_timing_window_elapsed_ms(NULL) == GINDEMA_NULL_POINTER, "elapsed(NULL) is refused");
    gindema_timing_window_free(w);
}

static void check_watch(void) {
    printf("-- watch --\n");
    const uint8_t original[] = {1, 2, 3, 4, 5};
    const uint8_t tampered[] = {1, 2, 99, 4, 5};
    GindemaWatch *watch = gindema_watch_new(original, sizeof(original));
    CHECK(watch != NULL, "a watch records the original data");
    GindemaGuardState *state = gindema_guard_state_new();

    CHECK(gindema_watch_check(watch, original, sizeof(original), state) == 1,
          "unchanged data still matches");
    CHECK(gindema_guard_state_is_polluted(state) == 0, "and state stays clean");

    CHECK(gindema_watch_check(watch, tampered, sizeof(tampered), state) == 0,
          "tampered data no longer matches");
    CHECK(gindema_guard_state_is_polluted(state) == 1, "and state is now polluted");

    CHECK(gindema_watch_new(NULL, 4) == NULL, "null data with nonzero len is refused");
    GindemaWatch *empty = gindema_watch_new(NULL, 0);
    CHECK(empty != NULL, "null data with zero len is accepted (a real empty region)");

    gindema_watch_free(watch);
    gindema_watch_free(empty);
    gindema_guard_state_free(state);
}

static void check_guarded_values(void) {
    printf("-- guarded values --\n");
    GindemaGuardState *state = gindema_guard_state_new();

    GindemaGuardedI64 *score = gindema_guarded_i64_new(1000, -1);
    int64_t out_i = 0;
    CHECK(gindema_guarded_i64_read(score, state, &out_i) == GINDEMA_OK && out_i == 1000,
          "guarded i64 reads the real value while clean");

    GindemaGuardedF64 *health = gindema_guarded_f64_new(100.0, -1.0);
    double out_f = 0.0;
    CHECK(gindema_guarded_f64_read(health, state, &out_f) == GINDEMA_OK && out_f == 100.0,
          "guarded f64 reads the real value while clean");

    gindema_guard_state_pollute(state);
    gindema_guarded_i64_read(score, state, &out_i);
    CHECK(out_i == -1, "guarded i64 falls back to its decoy once polluted");
    gindema_guarded_f64_read(health, state, &out_f);
    CHECK(out_f == -1.0, "guarded f64 falls back to its decoy once polluted");

    gindema_guarded_i64_free(score);
    gindema_guarded_f64_free(health);
    gindema_guard_state_free(state);
}

static void check_checksum(void) {
    printf("-- checksum --\n");
    const uint8_t data[] = {9, 8, 7};
    const uint8_t other[] = {1, 2, 3};
    uint64_t a = 0, b = 0, c = 0;
    CHECK(gindema_checksum(data, sizeof(data), &a) == GINDEMA_OK, "checksum computes");
    gindema_checksum(data, sizeof(data), &b);
    gindema_checksum(other, sizeof(other), &c);
    CHECK(gindema_checksums_match(a, b) == 1, "same data checksums match");
    CHECK(gindema_checksums_match(a, c) == 0, "different data checksums don't");
}

static void check_container(void) {
    printf("-- container (reading a real gindema-cli pack fixture) --\n");
    /* fixture.gctn was built with: gindema-cli pack fixture.gctn asset0.bin
     * asset1.bin --honeypots 2 --seed 7
     * asset0.bin: "hello from asset zero"
     * asset1.bin: "this is asset one, a bit longer than asset zero" */
    static const char *KEY_B64 = "e3waxD4muVUr6MsNGpjo7ZXiYCJ3O/dq6W5XhRY4gOM=";
    static const char *EXPECTED0 = "hello from asset zero";
    static const char *EXPECTED1 = "this is asset one, a bit longer than asset zero";

    uint8_t key[GINDEMA_CONTAINER_KEY_LEN];
    CHECK(gindema_container_key_from_base64(KEY_B64, key) == GINDEMA_OK, "the fixture key parses");
    CHECK(gindema_container_key_from_base64("not valid base64 at all!!", key) == GINDEMA_INVALID_KEY,
          "garbage key text is refused");

    FILE *f = fopen("fixture.gctn", "rb");
    CHECK(f != NULL, "fixture.gctn opens");
    if (!f) {
        return;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t *archive = malloc((size_t)size);
    fread(archive, 1, (size_t)size, f);
    fclose(f);

    GindemaContainerReader *reader = NULL;
    CHECK(gindema_container_open(archive, (size_t)size, key, &reader) == GINDEMA_OK && reader != NULL,
          "the archive opens with the right key");
    CHECK(gindema_container_asset_count(reader) == 2, "it reports 2 real assets");

    int64_t len0 = gindema_container_read_asset_len(reader, 0);
    CHECK(len0 == (int64_t)strlen(EXPECTED0), "asset 0's length matches");
    uint8_t buf0[256];
    int64_t written0 = gindema_container_read_asset(reader, 0, buf0, sizeof(buf0));
    CHECK(written0 == len0 && memcmp(buf0, EXPECTED0, (size_t)written0) == 0,
          "asset 0's bytes match exactly");

    int64_t len1 = gindema_container_read_asset_len(reader, 1);
    CHECK(len1 == (int64_t)strlen(EXPECTED1), "asset 1's length matches");
    uint8_t buf1[256];
    int64_t written1 = gindema_container_read_asset(reader, 1, buf1, sizeof(buf1));
    CHECK(written1 == len1 && memcmp(buf1, EXPECTED1, (size_t)written1) == 0,
          "asset 1's bytes match exactly");

    uint8_t tiny[1];
    CHECK(gindema_container_read_asset(reader, 0, tiny, sizeof(tiny)) == GINDEMA_BUFFER_TOO_SMALL,
          "a too-small buffer is refused, not overrun");

    CHECK(gindema_container_read_asset_len(reader, 999) == GINDEMA_INVALID_ASSET_ID,
          "an out-of-range asset id is reported");

    GindemaContainerReader *wrong = NULL;
    uint8_t bad_key[GINDEMA_CONTAINER_KEY_LEN];
    memset(bad_key, 0xAA, sizeof(bad_key));
    CHECK(gindema_container_open(archive, (size_t)size, bad_key, &wrong) == GINDEMA_DECRYPT_FAILED,
          "the wrong key is rejected, not silently accepted");

    gindema_container_free(reader);
    gindema_container_free(NULL); /* must not crash */
    free(archive);
}

int main(void) {
    printf("gindema smoke test (C, real gindema-guard and gindema-container)\n");
    check_guard_state();
    check_timing_window();
    check_watch();
    check_guarded_values();
    check_checksum();
    check_container();
    printf("%d/%d checks passed\n", g_checks - g_failed, g_checks);
    return g_failed == 0 ? 0 : 1;
}

/*
 * Build and run against the static library:
 *   gcc -Wall -Wextra -o test_static test.c -I. -L../../../target/debug -lgindema -lpthread -ldl -lm
 *   ./test_static
 *
 * Build and run against the shared library:
 *   gcc -Wall -Wextra -o test_shared test.c -I. -L../../../target/debug -lgindema
 *   LD_LIBRARY_PATH=../../../target/debug ./test_shared
 *
 * (paths above are relative to this file; adjust -L for a release build)
 */
