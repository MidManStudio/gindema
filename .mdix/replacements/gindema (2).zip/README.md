# gindema

Closed-source code/binary protection core **and** gameplay video/image poisoning tool, in one workspace, distributed as public CLIs. Blocks AI-assisted decompilation and reverse engineering, and disrupts AI vision models that would otherwise clone a game from posted gameplay footage.

## Status

Scaffold stage for `gindema-*` and `mirage-*`: crate structure is real, the
logic inside each isn't written yet. `pixelflip-*` is real and working.

## A real MSRV problem, not a guess

This workspace is pinned to `rust-version = "1.75"` (`[workspace.package]`
in the root `Cargo.toml`), inherited from mid-engine's convention. As of
building `pixelflip-*`, that floor does not actually hold against current
crates.io dependencies: `cargo check` against current `image = "0.25"`,
current `clap = "4.6"`, and `dixscript = "1.0"` all fail the same way,
Cargo 1.75 can't parse manifests that require the `edition2024` feature,
which several of their transitive dependencies now declare. Pinning
`pixelflip-*` to older, pre-`edition2024` exact versions (`image =
"=0.24.9"`, `clap = "=4.5.4"`, `anyhow = "=1.0.86"`) does compile and pass
tests under 1.75, but that's a workaround, not a fix, and it doesn't touch
`gindema-container`'s dependency on `dixscript`, which hits the same wall.
`edition2024` only works on Rust 1.85+, which is also what DixScript's own
README badge says (its `Cargo.toml` metadata still claims 1.75). Bumping
this workspace's `rust-version` to 1.85 is the likely real fix; not yet
done because changing the whole workspace's floor isn't a call to make
unilaterally.

## Workspace layout

Protection core:
- `crates/gindema-common` - shared types/errors (used workspace-wide)
- `crates/gindema-vm` - the custom bytecode VM
- `crates/gindema-obfuscate` - compiler passes
- `crates/gindema-guard` - runtime anti-tamper watchdog
- `crates/gindema-container` - encrypted asset container (built on dixscript)
- `crates/gindema-ptr` - vendored pointer primitives
- `crates/gindema-bits` - vendored bit-level I/O
- `crates/gindema-cli` - the distributable protection-core CLI

Video/image poisoning (placeholder name "mirage", rename before shipping):
- `crates/mirage-core` - perturbation algorithms
- `crates/mirage-ffmpeg` - FFmpeg integration
- `crates/mirage-cli` - the distributable video-poisoning CLI

Visual effects (unrelated to the anti-AI purpose, just a styling tool):
- `crates/pixelflip-core` - pattern-based pixel negation effects
- `crates/pixelflip-cli` - the distributable effects CLI

## License

Proprietary, MidManStudio. See `LICENSE`.
